-- ============================================================================
-- Traveler — admin tier migration
--
-- Run ONCE in the Supabase SQL Editor. Safe to re-run (everything is guarded).
--
-- Adds a third permission tier so "can edit builds" and "can manage people" are
-- no longer the same thing:
--
--   no editors row      ->  viewer  : reads everything, saves nothing
--   role = 'editor'     ->  editor  : full read/write on planning data
--   role = 'admin'      ->  admin   : editor, plus manages accounts and roles
--
-- IMPORTANT: put your own email in section 2 below (two places) before running,
-- or you will have no admin and no way to create one from the app. Section 2c
-- verifies it worked — if that query returns nothing, stop and fix the email.
-- ============================================================================


-- ----------------------------------------------------------------------------
-- 1. Role column
-- ----------------------------------------------------------------------------
alter table public.editors
  add column if not exists role text not null default 'editor';

alter table public.editors
  drop constraint if exists editors_role_check;
alter table public.editors
  add constraint editors_role_check check (role in ('editor', 'admin'));


-- ----------------------------------------------------------------------------
-- 2. Bootstrap the first admin
--
--    >>> Replace the email in BOTH statements below with your own. <<<
--
--    Two statements, because the row may or may not already exist:
--      2a promotes an existing editors row to admin
--      2b creates the row if there wasn't one
--    Only one of them will do anything, and running both is always safe.
--
--    Both match against auth.users rather than editors.email, so a stale email
--    in the editors table can't cause a silent miss. This must leave you as an
--    admin — step 6 installs a trigger that blocks any change leaving zero
--    admins, so getting this wrong makes the editors table read-only.
-- ----------------------------------------------------------------------------

-- 2a. Already has a row -> make it admin.
update public.editors e
set role = 'admin'
from auth.users u
where u.id = e.user_id
  and lower(trim(u.email)) = lower(trim('aaron@windriverbuilt.com'));

-- 2b. No row yet -> create one as admin.
insert into public.editors (user_id, email, role)
select u.id, u.email, 'admin'
from auth.users u
where lower(trim(u.email)) = lower(trim('aaron@windriverbuilt.com'))
  and not exists (
    select 1 from public.editors e where e.user_id = u.id
  );

-- 2c. Confirm before continuing. This MUST return at least one row.
--     If it's empty, stop: the email above doesn't match any account. Check the
--     exact spelling in Authentication -> Users and fix it before running on.
select u.email, e.role
from public.editors e
join auth.users u on u.id = e.user_id
where e.role = 'admin';


-- ----------------------------------------------------------------------------
-- 3. is_admin()
--
-- SECURITY DEFINER is load-bearing twice over: it lets the function read
-- `editors` regardless of that table's own read policy, AND it prevents
-- infinite recursion when the policies below call it while guarding `editors`.
-- The pinned search_path stops a caller shadowing `editors` with their own table.
-- ----------------------------------------------------------------------------
create or replace function public.is_admin()
returns boolean
language sql
stable
security definer
set search_path to 'public'
as $$
  select exists (
    select 1 from editors
    where user_id = auth.uid() and role = 'admin'
  );
$$;

grant execute on function public.is_admin() to authenticated;
revoke execute on function public.is_admin() from anon;


-- ----------------------------------------------------------------------------
-- 4. Who may change permissions
--
-- Gated on is_admin(), NOT is_editor(). If this said is_editor(), any editor
-- could promote themselves to admin — the whole tier would be decorative.
-- ----------------------------------------------------------------------------
drop policy if exists "read editors"          on public.editors;
drop policy if exists "read own editor row"   on public.editors;
drop policy if exists "admins manage editors" on public.editors;

-- Everyone signed in may check their own row; admins may read all of them.
create policy "read own editor row" on public.editors
  for select to authenticated
  using (user_id = auth.uid() or public.is_admin());

-- Only admins may insert, update, or delete.
create policy "admins manage editors" on public.editors
  for all to authenticated
  using (public.is_admin())
  with check (public.is_admin());


-- ----------------------------------------------------------------------------
-- 5. list_people()
--
-- The browser cannot read auth.users, and shouldn't be able to. This exposes a
-- deliberately narrow slice, and returns nothing at all unless the caller is an
-- admin — the `where public.is_admin()` is the access check. auth.uid() still
-- reflects the real caller inside a SECURITY DEFINER function, so this is safe.
-- ----------------------------------------------------------------------------
create or replace function public.list_people()
returns table (
  user_id         uuid,
  email           text,
  role            text,
  confirmed       boolean,
  last_sign_in_at timestamptz,
  created_at      timestamptz
)
language sql
stable
security definer
set search_path to 'public'
as $$
  select
    u.id,
    u.email::text,
    coalesce(e.role, 'viewer')::text,
    (u.email_confirmed_at is not null),
    u.last_sign_in_at,
    u.created_at
  from auth.users u
  left join editors e on e.user_id = u.id
  where public.is_admin()
  order by
    case coalesce(e.role, 'viewer')
      when 'admin'  then 1
      when 'editor' then 2
      else 3
    end,
    lower(u.email);
$$;

grant execute on function public.list_people() to authenticated;
revoke execute on function public.list_people() from anon;


-- ----------------------------------------------------------------------------
-- 6. Never allow zero admins
--
-- Without this, one careless demotion locks everybody out of user management
-- permanently — recoverable only by coming back here with SQL.
-- ----------------------------------------------------------------------------
create or replace function public.editors_require_admin()
returns trigger
language plpgsql
security definer
set search_path to 'public'
as $$
begin
  if (select count(*) from editors where role = 'admin') = 0 then
    raise exception 'At least one admin must remain. Promote someone else first.';
  end if;
  return null;
end;
$$;

drop trigger if exists editors_require_admin on public.editors;
create trigger editors_require_admin
  after insert or update or delete on public.editors
  for each statement execute function public.editors_require_admin();


-- ----------------------------------------------------------------------------
-- 7. Deleting an account removes its permission row
--
-- This is the failure we already hit once: a deleted account left a dangling
-- editors row, and the symptom was a silent inability to save.
-- ----------------------------------------------------------------------------
alter table public.editors
  drop constraint if exists editors_user_fk;
alter table public.editors
  add constraint editors_user_fk
  foreign key (user_id) references auth.users(id) on delete cascade;


-- ----------------------------------------------------------------------------
-- 8. Verify — expect exactly one row per account, and at least one admin
-- ----------------------------------------------------------------------------
select
  u.email,
  coalesce(e.role, 'viewer') as tier,
  (u.email_confirmed_at is not null) as confirmed
from auth.users u
left join public.editors e on e.user_id = u.id
order by 2, 1;
